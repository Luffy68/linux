import yaml


class Config:
    def __init__(self, config='config.yaml'):
        self.config = config

    def read(self, module):
        try:
            data = yaml.safe_load(open(self.config))
            return data[module]
        except:
            return False
