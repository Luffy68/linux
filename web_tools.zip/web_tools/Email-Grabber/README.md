# :email: EMAIL LIST GRABBER V2:
>Collect emails via a list of websites using this script!
>
           s,                                     .s
            ss,                                 .ss               666
            'SsSs,                           .sSsS'               {$}
             sSs'sSs,                    .sSs  sSs                {$}
              sSs  'sSs,              .sSs'   sSs                 {$}
               sS,    'sSs,         .sSs'    .Ss                  {$}
               'Ss       'sSs,   .sSs'       sS'                  {$}                
                sSs         ' .sSs'         sSs                   {$}      
                 sSs       .sSs' ..,       sSs              {+}{+}{$}{+}{+}       
                  sS,   .sSs'     'sSs,   .Ss                     {$}       
                  'Ss .Ss'           'sSs. ''                     {$}       
                   sSs '                'sSs,                     {$}
              .sS.'sSs                 .. 'sSs,     [+]-: KTN / @palemoongod
            .sSs'    sS,               .Ss    'sSs, [+]-: FAST EMAIL GRABBER
         .sSs'       'Ss               sS'       'sSs,
      .sSs'           sSs             sSs           'sSs,

# :gift: FEATURES:
>[1]- SMART

>[2]- MULTITHREADING

>[3]- PATHS ON OPTIONS: EDIT PATHS.txt TO ADD MORE PATHS 

>[4]- SMART


# :pencil: USAGE:
> **python3 script.py -h**

> **DEMO: https://asciinema.org/a/BcmfsXefam9JhPOYwDgpToDvH**

![alt text](https://i.imgur.com/8sakXu6.png)
